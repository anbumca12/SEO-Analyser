﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Text.RegularExpressions;
using HtmlAgilityPack;
using System.Net;

namespace SEOAnalyser.Common
{
    public class Utils
    {
        /// <summary>
        /// Checking URL Valid or Not
        /// </summary>
        /// <param name="url">Url String</param>
        /// <returns>If Valid, returns True else False</returns>
        public static bool IsURLValid(string url)
        {
            var isValidURL = false;
            try
            {
                var web = new HtmlWeb();
                var docURL = web.Load(url);
                if (docURL != null)
                {
                    isValidURL = true;
                }
            }
            catch (UriFormatException)
            {
                throw new Exception("Wrong URL format.");
            }
            catch (WebException)
            {
                throw new Exception("URL not valid or page not responding.");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isValidURL;
        }

        /// <summary>
        /// Getting ExternalLinks From Input Text
        /// </summary>
        /// <param name="text">HTML String</param>
        /// <returns>URL List</returns>
        public static List<string> GetAllExternalLinksFromText(string text)
        {
            List<string> listofURL = new List<string>();
            try
            {
                MatchCollection mc = Regex.Matches(text, Constants.GetHttpRegexCondition);
                foreach (Match match in mc)
                {
                    listofURL.Add(match.Value);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listofURL;
        }

        /// <summary>
        /// Getting Stop words from string
        /// </summary>
        /// <param name="text">Sentence</param>
        /// <returns>Stop Words List</returns>
        public static List<string> GetStopWords(string text)
        {
            var stopWords = new List<string>();
            try
            {
                List<string> words = SplitSentenceIntoWords(text.ToLower());
                string[] stopWordsArray = Constants.StopWords.Split(',');

                foreach (string word in words)
                {
                    if (stopWordsArray.Contains(word))
                        stopWords.Add(word);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return stopWords;
        }

        /// <summary>
        /// Splitting Sentence into Words
        /// </summary>
        /// <param name="sentence">Sentence</param>
        /// <returns>Words List</returns>
        public static List<string> SplitSentenceIntoWords(string sentence)
        {
            var words = new List<string>();
            sentence = sentence.Trim();
            try
            {
                if (sentence != null && sentence != string.Empty)
                    words = Regex.Split(sentence.Trim(), @"\W+").ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return words;
        }

        /// <summary>
        /// Converting List to Dictonary
        /// </summary>
        /// <param name="listofString">List of String</param>
        /// <returns>Dictonary of value and it's count</returns>
        public static Dictionary<string, int> GroupListOfString(List<string> listofString)
        {
            try
            {
                listofString = listofString.Where(x => x != string.Empty).ToList().OrderBy(x=> x).ToList();
                return listofString.GroupBy(word => word)
                   .ToDictionary(group => group.Key, group => group.Count());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// COnverting Dictionary to Datatable
        /// </summary>
        /// <param name="input">Dictionary value</param>
        /// <returns>Datatable</returns>
        public static DataTable ConvertDictionaryToDataTable(Dictionary<string, int> input)
        {
            var returnTable = new DataTable();
            returnTable.Columns.Add("KeyWord", typeof(string));
            returnTable.Columns.Add("Value", typeof(int));
            try
            {
                foreach (var dic in input)
                {
                    DataRow dr = returnTable.NewRow();
                    dr["KeyWord"] = dic.Key;
                    dr["Value"] = dic.Value;
                    returnTable.Rows.Add(dr);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnTable;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Xml;
using System.Web.UI.HtmlControls;
using SEOAnalyser.Common;
using SEOAnalyser.Business;

namespace SEOAnalyser
{
    public partial class _Default : System.Web.UI.Page
    {
        #region -- Page Load --
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                divGrid.Visible = false;
        }
        #endregion

        #region -- Button Submit Event --
        protected void btnSubmit_click(object sender, EventArgs e)
        {
            string searchText = txtInput.InnerText;
            ClearGridView();
            if (searchText != string.Empty)
            {
                try
                {
                    if (chkStopWord.Checked)
                    {
                        Dictionary<string, int> listStopWords = chkIsUrl.Checked ? AnalysisURLManager.GetStopWords(searchText) : AnalysisTextManager.GetStopWords(searchText);
                        DataTable dtStopWOrds = Utils.ConvertDictionaryToDataTable(listStopWords);
                        ViewState["StopWords"] = dtStopWOrds;
                        gvStopWords.DataSource = dtStopWOrds;
                        gvStopWords.DataBind();
                    }
                    if (chkNoOfWords.Checked)
                    {
                        Dictionary<string, int> listAllWords = chkIsUrl.Checked ? AnalysisURLManager.GetAllWords(searchText) : AnalysisTextManager.GetAllWords(searchText);
                        DataTable dtAllWOrds = Utils.ConvertDictionaryToDataTable(listAllWords);
                        ViewState["TotalWords"] = dtAllWOrds;
                        gvAllWords.DataSource = dtAllWOrds;
                        gvAllWords.DataBind();
                    }
                    if (chkMetaTag.Checked)
                    {
                        Dictionary<string, int> listMetaTags = chkIsUrl.Checked ? AnalysisURLManager.GetMetaTagValue(searchText) : AnalysisTextManager.GetMetaTagValue(searchText);
                        DataTable dtMetaTags = Utils.ConvertDictionaryToDataTable(listMetaTags);
                        ViewState["MetaTags"] = dtMetaTags;
                        gvMetaTags.DataSource = dtMetaTags;
                        gvMetaTags.DataBind();
                    }
                    if (chkExternalLink.Checked)
                    {
                        Dictionary<string, int> listExternalLinks = chkIsUrl.Checked ? AnalysisURLManager.GetAllExternalLinks(searchText) : AnalysisTextManager.GetAllExternalLinks(searchText);
                        DataTable dtExternalLinks = Utils.ConvertDictionaryToDataTable(listExternalLinks);
                        ViewState["ExternalLinks"] = dtExternalLinks;
                        gvExternalLinks.DataSource = dtExternalLinks;
                        gvExternalLinks.DataBind();
                    }
                    divGrid.Visible = true;
                }
                catch (Exception ex)
                {
                    PopupMessage(ex.Message.ToString());
                }
            }
            else
                PopupMessage("Kindly enter the search text.");
        }

        protected void btnClear_click(object sender, EventArgs e)
        {
            txtInput.InnerText = string.Empty;
            chkIsUrl.Checked = false;
            chkStopWord.Checked = false;
            chkNoOfWords.Checked = false;
            chkMetaTag.Checked = false;
            chkExternalLink.Checked = false;

            ClearGridView();
            divGrid.Visible = false;
        }
        #endregion

        #region -- Page Indexing Events --

        protected void gvStopWords_OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvStopWords.PageIndex = e.NewPageIndex;
            var dt = (DataTable)ViewState["StopWords"];
            if (dt != null)
                FillGrid(gvStopWords, dt, SortExpression, false);
        }

        protected void gvAllWords_OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvAllWords.PageIndex = e.NewPageIndex;
            var dt = (DataTable)ViewState["TotalWords"];
            if (dt != null)
                FillGrid(gvAllWords, dt, SortExpression, false);
        }

        protected void gvMetaTags_OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvMetaTags.PageIndex = e.NewPageIndex;
            var dt = (DataTable)ViewState["MetaTags"];
            if (dt != null)
                FillGrid(gvMetaTags, dt, SortExpression, false);
        }

        protected void gvExternalLinks_OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvExternalLinks.PageIndex = e.NewPageIndex;
            var dt = (DataTable)ViewState["ExternalLinks"];
            if (dt != null)
                FillGrid(gvExternalLinks, dt, SortExpression, false);
        }
        #endregion

        #region -- Sorting Events --
        protected void gvStopWords_OnSorting(object sender, GridViewSortEventArgs e)
        {
            var dt = (DataTable)ViewState["StopWords"];
            if (dt != null)
                FillGrid(gvStopWords, dt, e.SortExpression, true);
        }

        protected void gvAllWords_OnSorting(object sender, GridViewSortEventArgs e)
        {
            var dt = (DataTable)ViewState["TotalWords"];
            if (dt != null)
                FillGrid(gvAllWords, dt, e.SortExpression, true);
        }

        protected void gvMetaTags_OnSorting(object sender, GridViewSortEventArgs e)
        {
            var dt = (DataTable)ViewState["MetaTags"];
            if (dt != null)
                FillGrid(gvMetaTags, dt, e.SortExpression, true);
        }

        protected void gvExternalLinks_OnSorting(object sender, GridViewSortEventArgs e)
        {
            var dt = (DataTable)ViewState["ExternalLinks"];
            if (dt != null)
                FillGrid(gvExternalLinks, dt, e.SortExpression, true);
        }
        #endregion

        #region -- Methods --

        private string SortExpression
        {
            get { return ViewState["SortExpression"] != null ? ViewState["SortExpression"].ToString() : "KeyWord"; }
            set { ViewState["SortExpression"] = value; }
        }

        private void FillGrid(GridView grid, DataTable dt, string SortExpression, bool isSorting)
        {
            DataView dv = dt.AsDataView();
            if (ViewState["SortExpression"] != null && ViewState["SortDirection"] != null)
            {
                if (isSorting)
                {
                    if (ViewState["SortExpression"].ToString() == SortExpression)
                    {
                        if (ViewState["SortDirection"].ToString() == "ASC")
                            ViewState["SortDirection"] = "DESC";
                        else
                            ViewState["SortDirection"] = "ASC";
                    }
                    else
                    {
                        ViewState["SortExpression"] = SortExpression;
                        ViewState["SortDirection"] = "ASC";
                    }
                }
            }
            else
            {
                ViewState["SortExpression"] = SortExpression;
                ViewState["SortDirection"] = "ASC";
            }
            dv.Sort = ViewState["SortExpression"] + " " + ViewState["SortDirection"];
            grid.DataSource = dv.ToTable();
            grid.DataBind();
        }

        private void PopupMessage(string message)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('" + message.Replace("'","") + "');", true);
        }

        private void ClearGridView()
        {
            gvStopWords.DataSource = null;
            gvStopWords.DataBind();
            gvAllWords.DataSource = null;
            gvAllWords.DataBind();
            gvMetaTags.DataSource = null;
            gvMetaTags.DataBind();
            gvExternalLinks.DataSource = null;
            gvExternalLinks.DataBind();
        }
        #endregion
    }
}

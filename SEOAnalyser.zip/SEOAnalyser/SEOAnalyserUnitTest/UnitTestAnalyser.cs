﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SEOAnalyser;
using SEOAnalyser.Business;
using SEOAnalyser.Common;
using System.Data;
namespace SEOAnalyserUnitTest
{
    [TestClass]
    public class UnitTestAnalyser
    {
        [TestMethod]
        public void TestForAnalysisTextManager()
        {
            Dictionary<string, int> expectedResult;
            var actualResult = new Dictionary<string, int>();
            try
            {
                /*Test GetAllWords Method*/
                actualResult = AnalysisTextManager.GetAllWords("hi");
                expectedResult = new Dictionary<string, int> { { "hi", 1 } };
                CollectionAssert.AreEqual(expectedResult, actualResult);

                /*Test GetStopWords Method*/
                actualResult = AnalysisTextManager.GetStopWords("C# is a general-purpose, multi-paradigm programming language.");
                expectedResult = new Dictionary<string, int> { { "a", 1 }, { "is", 1 } };
                CollectionAssert.AreEqual(expectedResult, actualResult);

                /*Test GetAllExternalLinks Method*/
                actualResult = AnalysisTextManager.GetAllExternalLinks("C# is a general-purpose, multi-paradigm programming language.");
                expectedResult = new Dictionary<string, int> { };
                CollectionAssert.AreEqual(expectedResult, actualResult);

                /*Test GetMetaTagValue Method*/
                actualResult = AnalysisTextManager.GetMetaTagValue("");
                expectedResult = new Dictionary<string, int> { };
                CollectionAssert.AreEqual(expectedResult, actualResult);


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [TestMethod]
        public void TestForAnalysisURLManager()
        {
            var lsit = AnalysisURLManager.GetAllWords("https://www.google.com/") as Dictionary<string, int>;
            lsit = AnalysisURLManager.GetStopWords("https://www.google.com/") as Dictionary<string, int>;
            lsit = AnalysisURLManager.GetAllExternalLinks("https://www.google.com/") as Dictionary<string, int>;
            lsit = AnalysisURLManager.GetMetaTagValue("https://www.google.com/") as Dictionary<string, int>;
        }
        [TestMethod]
        public void TestForCommonMethods()
        {

            var dicInput=new Dictionary<string,int>();
            dicInput.Add("is",2);

            var expectedResult = new DataTable();
            expectedResult.Columns.Add("KeyWord", typeof(string));
            expectedResult.Columns.Add("Value", typeof(int));
            DataRow dr = expectedResult.NewRow();
            dr["KeyWord"] ="is";
            dr["Value"] =2;
            expectedResult.Rows.Add(dr);

            DataTable actualResult = Utils.ConvertDictionaryToDataTable(dicInput);

            Assert.AreEqual(expectedResult.Rows[0][0].ToString(), actualResult.Rows[0][0].ToString());
            Assert.AreEqual(expectedResult.Rows[0][1].ToString(), actualResult.Rows[0][1].ToString());
        }
    }
}

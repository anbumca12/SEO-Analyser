﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SEOAnalyser.Common;
using HtmlAgilityPack;
using System.Text.RegularExpressions;

namespace SEOAnalyser.Business
{
    public class AnalysisURLManager
    {

        #region -- Logic for URL --
        public static Dictionary<string, int> GetStopWords(string url)
        {
            var stopWordsList = new Dictionary<string, int>();
            try
            {
                if (Utils.IsURLValid(url))
                {
                    string bodyText = GetBodyStringFromUrl(url);
                    List<string> listOfWords = Utils.GetStopWords(bodyText);
                    stopWordsList = Utils.GroupListOfString(listOfWords);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return stopWordsList;
        }

        public static Dictionary<string, int> GetAllWords(string url)
        {
            var allWordsList = new Dictionary<string, int>();
            try
            {
                if (Utils.IsURLValid(url))
                {
                    string bodyText = GetBodyStringFromUrl(url);
                    List<string> listOfWords = Utils.SplitSentenceIntoWords(bodyText);
                    allWordsList = Utils.GroupListOfString(listOfWords);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return allWordsList;
        }

        public static Dictionary<string, int> GetMetaTagValue(string url)
        {
            var metaTagWordsList = new Dictionary<string, int>();
            var getHtmlDoc = new HtmlWeb();
            try
            {
                if (Utils.IsURLValid(url))
                {
                    var document = getHtmlDoc.Load(url);
                    var metaTags = document.DocumentNode.SelectNodes("//meta");
                    var listofWords = new List<string>();
                    if (metaTags != null)
                    {
                        foreach (var tag in metaTags)
                        {
                            string content = tag.Attributes["content"] != null ? tag.Attributes["content"].Value : "";
                            var hrefList = Regex.Replace(content, Constants.GetHttpRegexCondition, "$1");

                            if (!(hrefList.ToString().ToUpper().Contains("HTTP") || hrefList.ToString().ToUpper().Contains("://")))
                            {
                                List<string> words = Utils.SplitSentenceIntoWords(hrefList.ToLower());
                                listofWords.AddRange(words);
                            }
                        }
                    }
                    metaTagWordsList = Utils.GroupListOfString(listofWords);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return metaTagWordsList;
        }

        public static Dictionary<string, int> GetAllExternalLinks(string url)
        {
            var web = new HtmlWeb();
            var urlList = new Dictionary<string, int>();
            try
            {
                if (Utils.IsURLValid(url))
                {
                    var doc = web.Load(url);
                    var nodeSingle = doc.DocumentNode.SelectSingleNode("//html");
                    List<String> listofURL = Utils.GetAllExternalLinksFromText(nodeSingle.OuterHtml);
                    urlList = Utils.GroupListOfString(listofURL);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return urlList;
        }

        #endregion

        #region -- Methods --
        private static string GetBodyStringFromUrl(string url)
        {
            var getHtmlDoc = new HtmlWeb();
            string bodyText = string.Empty;
            try
            {
                var document = getHtmlDoc.Load(url);
                var body = document.DocumentNode.SelectSingleNode("//body");

                bodyText = GetPlainTextFromHtml(body.OuterHtml);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return bodyText;
        }

        private static string GetPlainTextFromHtml(string htmlString)
        {
            string htmlTagPattern = "<.*?>";
            var regexCss = new Regex("(\\<script(.+?)\\</script\\>)|(\\<style(.+?)\\</style\\>)", RegexOptions.Singleline | RegexOptions.IgnoreCase);
            htmlString = regexCss.Replace(htmlString, string.Empty);
            htmlString = Regex.Replace(htmlString, htmlTagPattern, string.Empty);
            htmlString = Regex.Replace(htmlString, @"^\s+$[\r\n]*", "", RegexOptions.Multiline);
            htmlString = htmlString.Replace("&nbsp;", string.Empty);

            return htmlString;
        }
        #endregion

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SEOAnalyser.Common;

namespace SEOAnalyser.Business
{
    public class AnalysisTextManager
    {
        public static Dictionary<string, int> GetStopWords(string searchText)
        {
            var stopWordsList = new Dictionary<string, int>();
            try
            {
                List<string> listOfWords = Utils.GetStopWords(searchText);
                stopWordsList = Utils.GroupListOfString(listOfWords);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return stopWordsList;
        }

        public static Dictionary<string, int> GetAllWords(string searchText)
        {
            var allWordsList = new Dictionary<string, int>();
            try
            {
                List<string> listOfWords = Utils.SplitSentenceIntoWords(searchText);
                allWordsList = Utils.GroupListOfString(listOfWords);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return allWordsList;
        }

        public static Dictionary<string, int> GetAllExternalLinks(string searchText)
        {
            var urlList = new Dictionary<string, int>();
            try
            {
                List<String> listofURL = Utils.GetAllExternalLinksFromText(searchText);
                urlList = Utils.GroupListOfString(listofURL);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return urlList;
        }


        public static Dictionary<string, int> GetMetaTagValue(string searchText)
        {
            return new Dictionary<string, int>();
        }
    }
}
